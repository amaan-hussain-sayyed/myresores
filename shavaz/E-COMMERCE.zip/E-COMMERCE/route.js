let express = require("express");
let { auth } = require("./middelwayyer/auth")

// from user controller...
let { register,
    login,
    changepassword,
    forget,
    reset,
    aboutMe,
    updatedme
} = require("./controller/usersController")

// from category controller....
let { addcategory,
    updatedcategory,
    findcategory,
} = require("./controller/categoryController");

//from product controller...
let { product } = require("./controller/productController")


let route = express();

route.use(express.json())

//user related api...

route.post("/api/v1/register", register);
route.get("/api/v1/login", login);
route.get("/api/v1/aboutme", auth("user"), aboutMe)
route.put("/api/v1/updatedme", auth("user"), updatedme)
route.put("/api/v1/changePassword", auth("user"), changepassword);
route.get("/api/v1/forget/password", forget);
route.put("/api/v1/reset/password", reset);

//category api...

route.post("/api/v1/category/add", auth("add_category"), addcategory);
route.put("/api/v1/category/updated", auth("updated_category"), updatedcategory);
route.get("/api/v1/category/search", findcategory);


//product api...
route.post("/api/v1/product", auth("add_product"), product)

module.exports = { route }