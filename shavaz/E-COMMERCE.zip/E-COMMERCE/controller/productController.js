let { productadd, searchproduct } = require("../model/productModel")

//controller for add product function
async function product(req, res) {

    let check = await productadd(req.body, req.userData).catch((err) => {
        return { error: err }
    })

    if (!check || check.error) {
        console.log(check.error)
        return res.status(check.status ? check.status : 500).send({ error: check.error ? check.error : "internal server error" })
    }

    return res.status(200).send({ data: check.data })
}

module.exports = { product }