let joi = require("joi")
let { Products } = require("../schema/productSchema");
let { Categories, Op } = require("../schema/categoreisSchema")
let { Product_category } = require("../schema/productCategorySchema");



//joi validation of add product...

async function valideproductadd(params) {

    let schema = joi.object({
        name: joi.string().min(10).max(100).required(),
        description: joi.string().min(40).max(1000).required(),
        details: joi.object().keys({
            material: joi.string().max(20).required(),
            size: joi.string().max(30).required(),
            color: joi.string().max(30).required()
        }).required(),
        stock: joi.number().required(),
        stock_alert: joi.number().required(),
        price: joi.number().required(),
        amount_after_discount: joi.number(),
    }).options({ abortEarly: false })

    let verify = schema.validate(params)

    if (verify.error) {
        let msg = [];

        for (let i of verify.error.details) {
            msg.push(i.message)
        }
        return { error: msg }
    }
    return { data: verify.value }
}

//funtion for adding product...

async function productadd(params, userData) {
    let valide = await valideproductadd(params).catch((err) => {
        return { error: err }
    })

    if (valide.error) {
        return { status: 300, error: valide.error }
    }

    params.details = JSON.stringify(params.details);

    let add = await Products.create({
        name: params.name,
        description: params.description,
        details: params.details,
        stock: params.stock,
        stock_alert: params.stock_alert,
        price: params.price,
        created_by: userData.id,
        updated_by: userData.id
    }).catch((err) => { return { error: err } })

    if (!add || add.error) {
        console.log("user", add)
        return { status: 400, error: "cannot add error" }
    }

    return { data: "product add succefull" }

}


//joi validation for search product
async function validesecrhproduct(params) {
    let schema = joi.object({
        name: joi.string(),
        category_id: joi.array().items(joi.number()),
    }).options({ abortEarly: false })

    let verify = schema.validate(params)
    if (verify.error) {
        let msg = [];
        for (let i of verify.error.details) {
            msg.push(i.message)
        }
        return { error: verify.error }
    }
    return { data: verify.value }

}

//function for search product
async function searchproduct(params) {
    let valid = await validesecrhproduct(params).catch((err) => {
        return { error: err }
    })

    if (!valid || valid.error) {
        return { status: 300, error: valid.error }
    }

    if (params.category_id) {

        let checkcategory = await Product_category.findAll({ where: { id: { [Op.in]: params.category_id } } }).catch((err) => {
            return { error: err }

        })

        if (!checkcategory || checkcategory.error) {
            return { status: 400, error: "internal sever error" }
        }

        if (checkcategory.length != params.category_id.length) {
            return { status: 300, error: "category not found" }
        }

        let product = await Products.findAll({ where: { id: { [Op.in]: checkcategory.product_id } } }).catch.error((err) => {
            return { error: err }
        })

        if (!product || product.error) {
            return { status: 300, error: "product not found" }
        }
        return { status: 200, data: product }
    }
    let result = {};
    if (params.name) {
        result = { where: { name: params.name } }
    }

    let product = await Products.findAll(result).catch((err) => {
        return { error: err }
    })

    if (!product || product.error) {
        return { status: 300, error: "product not found" }
    }

    return { data: product }


}

module.exports = {
    productadd, searchproduct
}
